# ALBERT CALLEJO AMAT — PORTFOLIO PROJECT BRIEF
> Document per a continuació en nou xat de Claude. Inclou totes les premises, decisions i estat actual.

---

## IDENTITAT I CONTEXT

**Nom:** Albert Callejo Amat
**Perfil:** Technical Artist / Animator / 3D — Freelance, Barcelona
**Identitats professionals:**
- ElèctricaVisuals — audiovisual i VR
- DIMA-VJ — videomapping i live shows
- 3datagraph.com — visualització científica i de dades

**Links importants:**
- Web: electricavisuals.com · dima-vj.com · 3datagraph.com
- ArtStation: artstation.com/albertcallejo
- GitHub: github.com/Electricavisuals
- Portfolio online: **https://Electricavisuals.github.io/portfolio**
- TimeObserver (app publicada): gumroad.com/l/ayten
- Tionet (joc publicat): Google Play

**Email:** albertcallejo@gmail.com
**Stack tècnic:** Houdini, Blender, Unreal Engine 5, Unity, ComfyUI/Stable Diffusion

---

## OBJECTIU DEL PROJECTE

Crear un **portfoli visual interactiu online** — un canvas infinit amb pan i zoom on es mostren les capacitats professionals d'Albert organitzades en "continents" temàtics amb "cards" de skill a dins.

**No és un portfoli convencional** — és un moodboard/mapa de capacitats navegable, fosc, estètica Stitch/Kinetic Canvas, que serveix per a entrevistes i presentacions a estudis.

---

## PREMISES I REQUISITS DEFINITS PER L'USUARI

### Estètica i disseny
- Estètica **Stitch / Kinetic Canvas** (Google Stitch design tool) — fosc, teal, JetBrains Mono + Inter
- Fons: `#0F0F1E` (floor) / `#111130` (panels)
- Accent principal: `#7EC8E3`
- **Colors per categoria** (inamovibles):
  - Animació: `#4B1528` continent / `#5C1830` cards / text `#F4C0D1`
  - TA & Pipeline: `#042C53` / `#0A3A6E` / text `#B5D4F4`
  - 3D Art: `#04342C` / `#065040` / text `#9FE1CB`
  - Real-time: `#26215C` / `#2E2880` / text `#CECBF6`
  - Cross: `#3A1408` / `#5C2510` / text `#F5C4B3`
  - Soft: `#2C2C2A` / `#3A3A38` / text `#D3D1C7`
- Border radius: 4px estàndard, 0px per panells dockats
- Fonts: Inter (UI) + JetBrains Mono (codi/tècnic)

### Navegació del canvas
- **Pan**: left click + arrossegar
- **Zoom**: scroll de roda, ancorat al cursor
- **Easing**: pan amb inèrcia (frena suaument en soltar), zoom amb easing suau
- **Vectorial pur**: el SVG s'ha d'integrar via `viewBox` manipulation, NO via CSS `transform:scale()` (provoca pixelació)
- Canvas és el SVG complet — no hi ha límit de zoom

### Cards de skill
- **Proporcions exactes** (mesurades a Inkscape): W=243px, H=276px (relatius)
- **Slot d'imatge**: W=228px, H=151px (54.7% de l'alçada de la card)
- Text empaquetament just fins al final de la card, sense espai mort
- Cada card conté: nom (bold), subtítol, 4 bullets màxim, exemple real (→)
- Les imatges dels slots es generaran amb ComfyUI

### Continents
- Formes orgàniques fetes amb boolean union de rectangles arrodonits a Inkscape
- Un sol contorn exterior per continent (sense vores internes visibles)
- Cards disposades en format hex/orgànic dins de cada continent, NO en graella rígida
- **Albert fa els continents a Inkscape** — Claude integra el SVG resultant al HTML

### Layout acordat (flux pipeline D)
- **Animació & Rigging** — esquerra, forma vertical alta (6 cards)
- **TA & Pipeline** — centre dalt, forma horitzontal ampla (11 cards)
- **3D Art** — dalt dreta (7 cards)
- **Real-time & Engines** — baix esquerra (6 cards — inclou Cinematic Director nou)
- **Cross-disciplinary** — baix centre-dreta, gran (10 cards)
- **Soft & Mindset** — illa petita dreta centre (4 cards)
- **Nucli** — centre, nom i identitat d'Albert
- **Illes**: Education, Languages, Hobbies, Links

### Requisits tècnics
- **Hosting**: GitHub Pages — https://Electricavisuals.github.io/portfolio
- **Repositori**: github.com/Electricavisuals/portfolio
- **Carpeta local**: \\MSI\d\CV\3D_Videojocs\PortfolioWeb
- **Deploy**: `push.bat` — fa git push des de PowerShell (CMD no suporta rutes UNC)
- **Un sol fitxer**: `index.html` conté tot — SVG inline + JS + CSS
- **No frameworks**: HTML pur, SVG inline, JS vanilla

### Coses que NO vol
- Cap graella rígida de cards
- Cap topbar de navegació pesada
- Cap finestra de codi (era del mockup de Stitch)
- Cap dependència de serveis de pagament
- Cap eina nova que requereixi aprenentatge llarg

---

## ESTAT ACTUAL DEL PROJECTE

### Fitxers a PortfolioWeb (\\MSI\d\CV\3D_Videojocs\PortfolioWeb\)
- `index.html` — web funcional amb SVG integrat, pan/zoom amb inèrcia
- `push.bat` — deploy automàtic a GitHub Pages
- `.gitignore` — ignora `zNO/` i `token portfolioool.txt`
- `layout_GOOD_001.svg` — **el SVG base fet per Albert a Inkscape** (8000×5440px)

### Estat del SVG (layout_GOOD_001.svg)
- Albert ha dissenyat els continents a Inkscape amb boolean union real
- Cards amb proporcions correctes (W=243, H=276, imatge H=151)
- **Pendent**: afegir imatges als slots (es generaran amb ComfyUI)
- **Pendent**: afegir card nova "Cinematic Director" al continent Real-time
- **Pendent**: integrar vídeos de YouTube als slots (via foreignObject)

### Web online
- URL: https://Electricavisuals.github.io/portfolio
- Pan: left click + drag, amb inèrcia suau
- Zoom: scroll wheel, ancorat al cursor, amb easing
- SVG inline via viewBox — 100% vectorial, sense pixelació
- Panel dret: propietats, links, control de zoom
- Fons: `#080C14`

---

## SKILLS COMPLETS (42 cards)

### ANIMATION & RIGGING (6)
1. **Life Giver** — Character & creature animation
2. **Curve Sculptor** — Animation curves & refinement
3. **State Machine Designer** — Animation systems in engines
4. **Motion Poet** — Motion graphics & AV choreography
5. **Prop Choreographer** — Objects, vehicles & machinery
6. **Timing Architect** — Game feel & action readability

### TECHNICAL ART & PIPELINE (11)
7. **Tool Forger** — Custom tools & scripts
8. **Bridge Builder** — App-to-app connectors
9. **Bottleneck Buster** — Pipeline bottleneck removal
10. **Batch Commander** — Mass asset processing
11. **Naming Sheriff** — Naming conventions & validation
12. **Time Observer** — Production logging (gumroad.com/l/ayten)
13. **Asset Shepherd** — Asset tracking
14. **Format Translator** — 3D format interchange
15. **Style Guide Keeper** — Technical art bibles
16. **QA Eye** — Visual & technical asset review
17. **Profiler** — Engine performance optimization

### 3D ART (7)
18. **UV Knife** — UV unwrapping & atlases
19. **Poly Surgeon** — Clean production modeling
20. **Procedural Garden** — Procedural assets & environments
21. **Surface Whisperer** — Materials, textures & look dev
22. **Light Reader** — Real-time lighting & look
23. **Atlas Architect** — Texture memory optimization
24. **Scan Integrator** — Photogrammetry pipeline

### REAL-TIME & ENGINES (6)
25. **Engine Whisperer** — Deep engine internals
26. **Particle Painter** — Real-time VFX
27. **Shader Tailor** — Custom materials & shaders
28. **Virtual Director** — Engine as AV production tool
29. **Cinematic Director** — In-engine cinematics & storytelling *(nou, pendent d'afegir al SVG)*
30. **Mapping Wizard** — Architectural videomapping

### CROSS-DISCIPLINARY (10)
31. **Generalist Sniper** — Any-role coverage
32. **Rapid Prototyper** — Functional concepts in 48h
33. **Live Show Gamifier** — AV live show gamification
34. **Interactive Architect** — Interactive experiences
35. **Visual Communicator** — Visual communication materials
36. **Science Storyteller** — Scientific illustration & explainers
37. **Point Cloud Sculptor** — 3D data & GIS visualization
38. **Product Revealer** — 3D product for advertising
39. **Fluid Narrator** — Fluid simulations for communication
40. **Data Sculptor** — Spatial data in 3D

### SOFT & MINDSET (4)
41. **Translator Node** — Art↔programming bridge
42. **R&D Scout** — New techniques research
43. **Solo Pipeline** — Full pipeline ownership (Tionet — Google Play)
44. **Multidisciplinary Receptor** — Adjacent domain knowledge

### ILLES
- **Education**: Master UPC · CIFO · SAE · Houdini self-training
- **Languages**: CA · ES · FR · EN
- **Hobbies**: RC Flight · Archery · DIY · Music · VJing
- **Links**: ArtStation · electricavisuals.com · gumroad

---

## WORKFLOW COMFYUI PER IMATGES DE CARDS

**Models disponibles:**
- dreamshaperXL_lightningDPMSDE.safetensors
- sd_xl_base_1.0 + sd_xl_refiner_1.0
- flux1-schnell-fp8
- ip-adapter-plus_sdxl_vit-h + clip_vision_h

**Estil de les imatges:** game app icon style, dark background, teal cyan and white, flat icon with subtle depth, clean sharp edges, mobile game UI aesthetic, no text

**Resolució:** 1664×1080px (proporció 308:199 de les cards × factor)

**Workflow:** `workflow_cards_t2i.json` — Text2Image pur amb DreamshaperXL Lightning, steps 8, CFG 2.0, dpmpp_sde karras

**Fitxer de referència de prompts:** `skills_full_list.md`

---

## PRÒXIMS PASSOS

- [ ] Generar imatges per a cada card amb ComfyUI i inserir-les al SVG (Inkscape clip)
- [ ] Afegir card "Cinematic Director" al SVG (SVG ja generat: `card_cinematic_director.svg`)
- [ ] Integrar vídeos de YouTube als slots via `<foreignObject>` al HTML
- [ ] Explorar Three.js per a futura versió 3D del canvas (referència: bruno-simon.com)
- [ ] Considerar Figma Sites per publicació alternativa

---

## NOTES TÈCNIQUES IMPORTANTS

### Git / GitHub Pages
- CMD no suporta rutes UNC (\\MSI\...) — sempre usar PowerShell
- Token GitHub guardat en zip xifrat a la carpeta del projecte
- GitHub detecta tokens en text pla i bloqueja el push
- Error 153 YouTube embed: afegir `referrerpolicy="strict-origin-when-cross-origin"` a l'iframe i meta tag al head

### Blender
- Transparency sobre si mateix: **Render Method → Dithered** (no Blended)
- HDR visible en llum però no en render: node **Light Path → Is Camera Ray → Mix Shader**
- GPU no renderitza: comprovar Edit → Preferences → System → Cycles Render Devices

### Inkscape
- Boolean union: `Path → Union` — les formes es fusionen en una sola
- Clip d'imatge: selecciona imatge + rectangle → `Object → Clip → Set`
- Round corners: **Extensions → Modify Path → Rounded Corners** (cal instal·lar extensió: github.com/jnweiger/inkscape-round-corners)
- Alinear i espacejar: `Ctrl+Shift+A` → Align and Distribute

### Houdini
- PolyExtrude per prim attribute: pestanya **Local Control → Distance Scale → zscale**, mode **Individual Elements**

---

## DESIGN SYSTEM (Kinetic Canvas — de Stitch)

```
Colors base:
  --bg: #0F0F1E (floor)
  --surface: #111130 (panels)
  --accent: #7EC8E3 (primary)
  --accent-light: #9CE4FF

Fonts:
  Inter — UI general
  JetBrains Mono — codi, labels tècnics

Border radius:
  0px — panells dockats
  4px — cards, botons
  full — status chips

Categoria colors (continent / card / text):
  Animació:   #4B1528 / #5C1830 / #F4C0D1
  TA:         #042C53 / #0A3A6E / #B5D4F4
  3D Art:     #04342C / #065040 / #9FE1CB
  Real-time:  #26215C / #2E2880 / #CECBF6
  Cross:      #3A1408 / #5C2510 / #F5C4B3
  Soft:       #2C2C2A / #3A3A38 / #D3D1C7
```
